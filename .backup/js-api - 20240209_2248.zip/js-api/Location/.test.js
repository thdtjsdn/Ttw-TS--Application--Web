var result0 = window.apis.location.getQueryArrayFromLocationSearch();
console.log(result0);

var result1 = window.apis.location.getQueryObjectFromLocationSearch();
console.log(result1);

if (result1['ttw-api-nTimeout']) {
    var n = Number(result1['ttw-api-nTimeout']);
    console.log(n);
    window.apis.location.startRepeatReloadTimeout(n);
}