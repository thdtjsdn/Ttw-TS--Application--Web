(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    var _idTimeout = -1;

    /**
     * 
     * @param {*} nTimeout 
     */
    O.reload = function (nTimeout) {
        var queryObject = window.apis.location.getQueryObjectFromLocationSearch();
        if (queryObject) {
            delete queryObject['ttw-api-nTimeout'];
            queryObject['ttw-api-nTimeout'] = nTimeout;
        }

        var url = window.location.origin + window.location.pathname + O.owner.createLocationSearchFromObject(queryObject);

        window.location.href = url;
    };

    /**
     * 
     * @param {*} nTimeout 
     */
    O.startRepeatReloadTimeout = function (nTimeout) {
        clearInterval(_idTimeout);
        _idTimeout = setTimeout(function () {
            O.reload(nTimeout);
        }, nTimeout);
    };

    O.stopRepeatReloadTimeout = function () {
        clearInterval(_idTimeout);
    };

    return window.TAPI.I(O);
})();