(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    /**
     * 
     * @param {Array} a 
     * @returns 
     */
    O.createLocationSearchFromArray = function (a) {
        var result = '?';
        var i = 0, iLen = a.length;
        for (; i < iLen; ++i) {
            result += '&' + a[i][0] + '=' + a[i][1];
        }

        result = result.replace('&', '');
        return result;
    };

    /**
     * 
     * @param {Object} o 
     * @returns 
     */
    O.createLocationSearchFromObject = function (o) {
        var result = '?';
        for (var s in o) {
            result += '&' + s + '=' + o[s];
        }

        result = result.replace('&', '');
        return result;
    };

    /**
     * 
     * @returns {String}
     */
    O.getLocationSearch = function () {
        var search = decodeURIComponent(window.location.search);
        search = search.replace('?', '');
        return search;
    };

    /**
     * 
     * @returns {Array}
     */
    O.getLocationSearchArray = function () {
        var search = O.getLocationSearch();
        var a = search.split('&');
        return a;
    };

    /**
     * 
     * @returns {Array}
     */
    O.getQueryArrayFromLocationSearch = function () {
        var a0 = O.getLocationSearchArray();

        var result = [];

        var io;
        var i = 0, iLen = a0.length;
        for (; i < iLen; ++i) {
            io = a0[i];
            var ioa = io.split('=');
            result.push(ioa);
        }

        return result;
    };

    /**
     * 
     * @returns {Object}
     */
    O.getQueryObjectFromLocationSearch = function () {
        var a0 = O.getLocationSearchArray();

        var result = {};

        var io;
        var i = 0, iLen = a0.length;
        for (; i < iLen; ++i) {
            io = a0[i];
            var ioa = io.split('=');
            result[ioa[0]] = ioa[1];
        }

        return result;
    };

    return window.TAPI.I(O);
})();