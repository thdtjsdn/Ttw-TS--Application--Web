var a = [
    { a: 1 }
    , { a: 2 }
    , { a: 3 }
    , { a: 4 }
    , { a: 5 }
];

a = window.apis.arrayCollection.sortJsonArrayByKey_Asc(a, 'a');
console.log(JSON.stringify(a, null, '\t'));

a = window.apis.arrayCollection.sortJsonArrayByKey_Desc(a, 'a');
console.log(JSON.stringify(a, null, '\t'));