(function () {
    var text = 'TAPI--Script.signalScript_Repeat30Seconds.js';
    console.log(text);
    return text;
})();