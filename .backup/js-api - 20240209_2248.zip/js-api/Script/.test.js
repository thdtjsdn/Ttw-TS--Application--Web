console.info(window.apis.script);

//Called only once after page loading is complete;
window.apis.script.signalScript_PageLoadEnd();

//Called every 30 seconds after page loading is complete;
window.apis.script.signalScript_Repeat30Seconds();