(function () {
    Object.defineProperty(window, "TAPI", { writable: false, configurable: false, value: {} });

    var T = window.TAPI;

    //Object DefineProperty;
    Object.defineProperty(T, "S", {
        writable: false, configurable: false
        , value: function (o, k, v) {
            Object.defineProperty(o, k, { writable: false, configurable: false, value: v });
        }
    });

    //Properties;
    T.S(T, "ATT_JS", 't-api');
    T.S(T, "ORIGIN", window.location.origin);
    T.S(T, "URL_JS_API", T.ORIGIN + '/js-api/');

    //api list;
    T.S(T, "L", {});

    //append api;
    T.S(T, "A", function (src, tapi) {
        var el = window.document.createElement('SCRIPT');
        el.setAttribute(T.ATT_JS, tapi);
        el.src = src;
        el.onload = function (e) { el.onload = null; e.target.remove(); };
        window.document.head.appendChild(el);
        return T.L[src];
    });

    //check api;
    T.S(T, "C", function () {
        var el = window.document.currentScript;
        if (!el) {
            el.remove();
            return false;
        }

        var o = T.L[el.src];
        if (o) {
            var apiName = el.getAttribute(T.ATT_JS);
            console.warn(apiName + ' - retry - ' + el.src);
            el.remove();
            return o;
        }
        else {
            return false;
        }
    });

    //get api;
    T.S(T, "G", async function (src, tapi) {
        var response = await fetch(src);
        var js = await response.text();
        var O = eval(js);
        return O;
    });

    //inject api;
    T.S(T, "I", function (O) {
        var el = window.document.currentScript;
        if (!el) {
            el.remove();
            return false;
        }

        var apiName = el.getAttribute(T.ATT_JS);
        console.log(apiName + ' - initialized - ' + el.src);
        var a = apiName.split('.');
        var io;
        var i = 0, iLen = a.length;
        for (; i < iLen; ++i) {
            if (!io) {
                if (!window[a[i]]) {
                    T.S(window, a[i], {});
                    io = window[a[i]];
                }
                else {
                    io = window[a[i]];
                }
            }
            else {
                if (!io[a[i]]) {
                    T.S(io, a[i], {});
                    io = io[a[i]];
                }
                else {
                    io = io[a[i]];
                }
            }
        }

        var ownerPackage = io;
        for (var s in O) {
            T.S(ownerPackage, s, O[s]);
        }

        if (!T.L[el.src]) { T.S(T.L, el.src, O); }
        if (!T.L[apiName]) { T.S(T.L, apiName, ownerPackage); }

        el.remove();

        T.S(O, 'owner', ownerPackage);

        return O;
    });

    //--------------------------------------------------;

    //short apis;

    T.S(T, 'ce', function (tagName) { return window.document.createElement(tagName); });

    T.S(T, 'ea', function (o, evtType, listener) { o.addEventListener(evtType, listener); });
    T.S(T, 'er', function (o, evtType, listener) { o.removeEventListener(evtType, listener); });
    T.S(T, 'eaid', function (id, evtType, listener) { T.ea(window.document.getElementById(id), evtType, listener); });
    T.S(T, 'erid', function (id, evtType, listener) { T.er(window.document.getElementById(id), evtType, listener); });

    T.S(T, 'ge', function (id) { return window.document.getElementById(id); });
    T.S(T, 'gesc', function (className) { return window.document.getElementsByClassName(className); });
    T.S(T, 'gest', function (tagName) { return window.document.getElementsByTagName(tagName); });
    T.S(T, 'gescc', function (o, className) { return o.getElementsByClassName(className); });
    T.S(T, 'gestc', function (o, tagName) { return o.getElementsByTagName(tagName); });
})();