(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    /**
     * 
     * @param {String} href 
     * @returns 
     */
    O.createElement__A = function (href) {
        var el = TAPI.ce('A');
        el.href = href;
        return el;
    };

    /**
     * 
     * @returns 
     */
    O.createElement__DIV = function () {
        var el = TAPI.ce('DIV');
        return el;
    };

    return window.TAPI.I(O);
})();