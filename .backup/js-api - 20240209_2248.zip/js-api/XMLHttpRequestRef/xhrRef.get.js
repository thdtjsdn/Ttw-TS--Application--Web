(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    /**
     * 
     * @param {XMLHttpRequest} xhr
     * @param {string} url ''
     * @param {Function} cb function(event){}
     * @returns 
     */
    O.get = function (xhr, url, cb) {
        xhr.open('GET', url);

        xhr.onerror = function (e) {
            console.error(e);
            if (cb) cb(e);
        };

        xhr.onloadend = function (e) {
            if (cb) cb(e);
        };

        xhr.send();

        return xhr;
    };

    /**
     * 
     * @param {XMLHttpRequest} xhr
     * @param {string} url ''
     * @param {object} headers [{ k : 'Content-Type', v : 'application/json' }, { k : '', v : '' }]
     * @param {Function} cb function(event){}
     * @returns 
     */
    O.get__Headers = function (xhr, url, headers, cb) {
        xhr.open('GET', url);

        var io;
        var i = 0, iLen = headers.length;
        for (; i < iLen; ++i) {
            io = headers[i];
            xhr.setRequestHeader(io.k, io.v);
        }

        xhr.onerror = function (e) {
            console.error(e);
            if (cb) cb(e);
        };

        xhr.onloadend = function (e) {
            if (cb) cb(e);
        };

        xhr.send();

        return xhr;
    };

    return window.TAPI.I(O);
})();