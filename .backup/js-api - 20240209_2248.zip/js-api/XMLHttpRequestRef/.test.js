var xhr = new XMLHttpRequest();
window.apis.xhrRef.get(xhr, 'http://thdtjsdn.com', (e) => {
    console.log(e.target.responseText);
});