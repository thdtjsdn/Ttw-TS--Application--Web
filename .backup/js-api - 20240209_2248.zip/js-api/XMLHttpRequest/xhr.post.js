(function () {
    var O = {};

    /**
     * 
     * @param {string} url ''
     * @param {object} requestData 
     * @param {Function} cb function(event){}
     * @returns 
     */
    O.post = function (xhr, url, requestData, cb) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url);

        xhr.onerror = function (e) {
            console.error(e);
            if (cb) cb(e);
        };

        xhr.onloadend = function (e) {
            if (cb) cb(e);
        };

        xhr.send(JSON.stringify(requestData));

        return xhr;
    };

    /**
     * @param {string} url ''
     * @param {object} requestData 
     * @param {object} headers [{ k : 'Content-Type', v : 'application/json' }, { k : '', v : '' }]
     * @param {Function} cb function(event){}
     * @returns 
     */
    O.post__Headers = function (xhr, url, headers, requestData, cb) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url);

        var io;
        var i = 0, iLen = headers.length;
        for (; i < iLen; ++i) {
            io = headers[i];
            xhr.setRequestHeader(io.k, io.v);
        }

        xhr.onerror = function (e) {
            console.error(e);
            if (cb) cb(e);
        };

        xhr.onloadend = function (e) {
            if (cb) cb(e);
        };

        xhr.send(JSON.stringify(requestData));

        return xhr;
    };

    return window.TAPI.I(O);
})();