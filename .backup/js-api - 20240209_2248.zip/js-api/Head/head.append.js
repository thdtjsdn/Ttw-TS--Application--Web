(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    /**
     * 
     * @param {string} href
     * @returns 
     */
    O.appendCSSToHead = function (href) {
        var el = window.document.createElement('LINK');
        el.rel = 'stylesheet';
        window.document.head.appendChild(el);
        el.href = href;

        return el;
    };

    /**
     * 
     * @param {string} url 
     * @returns 
     */
    O.appendJSToHead = function (url) {
        var el = window.document.createElement('script');
        window.document.head.appendChild(el);
        el.src = url;

        return el;
    };

    /**
     * 
     * @param {string} url 
     * @param {string} ttwApi 
     * @returns 
     */
    O.appendJSToHead__TAPI = function (url, tapi) {
        var el = O.appendJSToHead(url);
        el.setAttribute('t-api', tapi);
        return el;
    };

    return window.TAPI.I(O);
})();