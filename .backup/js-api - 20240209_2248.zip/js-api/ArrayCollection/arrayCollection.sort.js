(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    var _sortByFunc = {

        /**
         * 
         * @param item0 
         * @param item1 
         * @returns 
         */
        asc: (item0, item1) => {
            //if( typeof item0 === "undefined" ) return -1;
            //if( typeof item1 === "undefined" ) return 1;

            var key = item0.__proto__.__sortKey__;
            item1.__proto__.__sortKey__ = key;

            var x = item0[key];
            var y = item1[key];

            return (x < y) ? -1 : ((x > y) ? 1 : 0);

        },

        /**
         * 
         * @param item0 
         * @param item1 
         * @returns 
         */
        desc: (item0, item1) => {
            //if( typeof item0 === "undefined" ) return -1;
            //if( typeof item1 === "undefined" ) return 1;

            var key = item0.__proto__.__sortKey__;
            item1.__proto__.__sortKey__ = key;

            var x = item0[key];
            var y = item1[key];

            return (x < y) ? 1 : ((x > y) ? -1 : 0);
        }
    };

    /**
     * 
     * @param {array} a 
     * @param {string} key 
     * @returns 
     */
    O.sortJsonArrayByKey_Asc = function (a, key) {
        a[0].__proto__.__sortKey__ = key;

        a.sort(_sortByFunc.asc);

        var i = 0, iLen = a.length;
        for (; i < iLen; ++i) delete a[i].__proto__.__sortKey__;

        return a;
    }

    /**
     * 
     * @param {array} a 
     * @param {string} key 
     * @returns 
     */
    O.sortJsonArrayByKey_Desc = function (a, key) {
        a[0].__proto__.__sortKey__ = key;

        a.sort(_sortByFunc.desc);

        var i = 0, iLen = a.length;
        for (; i < iLen; ++i) {
            delete a[i].__proto__.__sortKey__;
        }

        return a;
    }

    return window.TAPI.I(O);
})();