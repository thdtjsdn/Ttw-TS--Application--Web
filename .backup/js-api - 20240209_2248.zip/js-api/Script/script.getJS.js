(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    /**
     * 
     * @param {string} url 
     * @param {Function} cb function(event){}
     */
    O.getJS = function (url, cb) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        xhr.onloadend = function (e) {
            try {
                var result = eval(xhr.responseText);
                if (cb) cb(e, result);
            }
            catch (err) {
                console.error(err.message, err.stack, this);
                return;
            }
        };
        xhr.send();
    };

    return window.TAPI.I(O);
})();