(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    O.remove = function (el) {
        try {
            //delete event listeners;
            //...

            el.remove();
        }
        catch (err) {

        }

        return el;
    };

    /**
     * 
     * @param {String} id 
     * @returns 
     */
    O.remove__id = function (id) {
        return O.remove(TAPI.ge(id));
    };

    return window.TAPI.I(O);
})();