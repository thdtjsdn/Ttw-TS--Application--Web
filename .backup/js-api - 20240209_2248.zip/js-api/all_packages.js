(function () {
    var HOST0 = 'http://localhost:49310';
    var HOST1 = HOST0 + '/js-api/';

    var FN = function (url, tapi) {
        window.TAPI.A(HOST1 + url, tapi);
    };

    FN('ArrayCollection/arrayCollection.sort.js', 'apis.arrayCollection');

    FN('Element/element.children.js', 'apis.element');
    FN('Element/element.create.js', 'apis.element');
    FN('Element/element.remove.js', 'apis.element');
    FN('Element/element.style.js', 'apis.element');

    FN('Head/head.append.js', 'apis.head');

    FN('Location/location.reload.js', 'apis.location');
    FN('Location/location.search.js', 'apis.location');

    FN('Script/script.getJS.js', 'apis.script');
    FN('Script/script.signalScript.js', 'apis.script');

    FN('XMLHttpRequest/xhr.get.js', 'apis.xhr');
    FN('XMLHttpRequest/xhr.post.js', 'apis.xhr');

    FN('XMLHttpRequestRef/xhrRef.get.js', 'apis.xhrRef');
    FN('XMLHttpRequestRef/xhrRef.post.js', 'apis.xhrRef');

    console.log(window.apis);
})();