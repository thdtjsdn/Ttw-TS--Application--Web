(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    /**
     * 
     * @param {HTMLElement} el 
     * @returns {Array}
     */
    O.getArrayFromChildren = function (el) {
        var r = [];
        var a = el.children;
        var i = 0, iLen = a.length;
        for (; i < iLen; ++i) {
            r.push(a[i]);
        }

        return r;
    };

    /**
     * 
     * @param {HTMLElement} el 
     * @param {String} value '', 'none', 'block', ...
     */
    O.allChildren__Display = function (el, value) {
        var a = el.children;
        var i = 0, iLen = a.length;
        for (; i < iLen; ++i) {
            a[i].style.display = value;
        }
    };
    O.allChildren__DisplayEmpty = function (el) { allChildren__Display(el, ''); };
    O.allChildren__DisplayNone = function (el) { allChildren__Display(el, 'none'); };

    /**
     * 
     * @param {HTMLElement} el 
     */
    O.allChildren__Remove = function (el) {
        var a = el.children;
        var i = 0, iLen = a.length;
        for (; i < iLen; ++i) {
            O.owner.remove(a[0]);
        }
    };

    return window.TAPI.I(O);
})();