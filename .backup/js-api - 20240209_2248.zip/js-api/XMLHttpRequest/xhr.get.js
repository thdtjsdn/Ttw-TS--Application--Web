(function () {
    var O = {};

    /**
     * 
     * @param {string} url ''
     * @param {Function} cb function(event){}
     * @returns 
     */
    O.get = function (url, cb) {
        var xhr = new XMLHttpRequest();

        xhr.open('GET', url);

        xhr.onerror = function (e) {
            console.error(e);
            if (cb) cb(e);
        };

        xhr.onloadend = function (e) {
            if (cb) cb(e);
        };

        xhr.send();

        return xhr;
    };

    /**
     * 
     * @param {string} url ''
     * @param {object} headers [{ k : 'Content-Type', v : 'application/json' }, { k : '', v : '' }]
     * @param {Function} cb function(event){}
     * @returns 
     */
    O.get__Headers = function (url, headers, cb) {
        var xhr = new XMLHttpRequest();

        xhr.open('GET', url);

        var io;
        var i = 0, iLen = headers.length;
        for (; i < iLen; ++i) {
            io = headers[i];
            xhr.setRequestHeader(io.k, io.v);
        }

        xhr.onerror = function (e) {
            console.error(e);
            if (cb) cb(e);
        };

        xhr.onloadend = function (e) {
            if (cb) cb(e);
        };

        xhr.send();

        return xhr;
    };

    return window.TAPI.I(O);
})();