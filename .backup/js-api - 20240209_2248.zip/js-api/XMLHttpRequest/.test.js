window.apis.xhr.get('http://thdtjsdn.com', (e) => {
    console.log(e.target.responseText);
});