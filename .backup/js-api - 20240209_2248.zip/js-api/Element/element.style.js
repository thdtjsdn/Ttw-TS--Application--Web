(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    (function () {
        _styles = {
            margin: '0px'
            , marginBottom: '0px'
            , marginLeft: '0px'
            , marginRight: '0px'
            , marginTop: '0px'
        };

        O.marginZero = function (el) { O.setStyles(el, _styles); }
    })();

    (function () {
        _styles = {
            padding: '0px'
            , paddingBottom: '0px'
            , padddingLeft: '0px'
            , padddingRight: '0px'
            , padddingTop: '0px'
        };
        O.paddingZero = function (el) { O.setStyles(el, _styles); }
    })();

    O.pointerDisable = function (el) { el.style.pointerEvents = 'none'; };

    /**
     * 
     * @param {Array} els 
     */
    O.pointerDisables = function (els) {
        var i = 0, iLen = els.length;
        for (; i < iLen; ++i) {
            O.pointerDisables(els[i]);
        }
    };

    O.pointerEnable = function (el) { el.style.pointerEvents = 'auto'; };

    /**
     * 
     * @param {Array} els 
     */
    O.pointerEnables = function (els) {
        var i = 0, iLen = els.length;
        for (; i < iLen; ++i) {
            O.pointerEnable(els[i]);
        }
    };

    /**
     * 
     * @param {HTMLElement} el 
     * @param {String} key 
     * @param {String} value 
     * @returns 
     */
    O.setStyle = function (el, key, value) {
        el.style[key] = value;
    };

    /**
     * 
     * @param {HTMLElement} el 
     * @param {Object} styles 
     */
    O.setStyles = function (el, styles) {
        for (var s in styles) {
            el.style[s] = styles[s];
        }
    };

    return window.TAPI.I(O);
})();