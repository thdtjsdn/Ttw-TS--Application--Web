(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    (function () {

        var _styles = {
            border: 'none'

            , margin: '0px'

            , overFlow: 'none'
            , overFlowX: 'none'
            , overFlowY: 'none'

            , padding: '0px'
        };

        /**
         * 
         * @param {String} src 
         * @param {Number} width 
         * @param {Number} height 
         * @returns 
         */
        O.create__NoFrame = function (src, width, height) {
            var el = TAPI.ce('IFRAME');

            O.owner.setStyles(el, _styles);

            el.style.width = width;
            el.style.height = height;

            el.src = src;

            return el;
        };

    })();

    return window.TAPI.I(O);
})();