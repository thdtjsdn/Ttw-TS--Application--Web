(function () {
    var text = 'TAPI--Script.signalScript_PageLoadEnd.js';
    console.log(text);
    return text;
})();