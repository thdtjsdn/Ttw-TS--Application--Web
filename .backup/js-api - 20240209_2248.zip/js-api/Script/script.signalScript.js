(function () {
    var O = window.TAPI.C(); if (O) return O;

    O = {};

    //Called only once after page loading is complete;
    (function () {
        var _b_signalScript_PageLoadEnd = false;

        O.signalScript_PageLoadEnd = function () {
            if (!_b_signalScript_PageLoadEnd) {
                _b_signalScript_PageLoadEnd = true;
                var url0 = window.TAPI.URL_JS_API + 'TAPI--Script.signalScript_PageLoadEnd.js'
                O.owner.getJS(url0, function (e, result) {
                    console.log(e);
                    console.log(result);
                });
            }
        };
    })();


    //Called every 30 seconds after page loading is complete;
    (function () {
        var _cnt_signalScript_Repeat30Seconds = 0;

        O.signalScript_Repeat30Seconds = function () {
            var url0 = window.TAPI.URL_JS_API + 'TAPI--Script.signalScript_Repeat30Seconds.js'
            O.owner.getJS(url0, function (e, result) {
                console.log(e);
                console.log(result);

                ++_cnt_signalScript_Repeat30Seconds;
                setTimeout(O.signalScript_Repeat30Seconds, 30000);
                return;
            });
        };
    })();

    return window.TAPI.I(O);
})();